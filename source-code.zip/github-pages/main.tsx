/// <reference types="vite/client" />
import React from 'react';
import {createRoot} from 'react-dom/client';
import Lab from '../app/lab';
import '../app/globals.css';
createRoot(document.getElementById('root')!).render(<Lab assetBase={import.meta.env.BASE_URL} contentUrl="https://jnu-hci-lab.sleekeel31.chatgpt.site/api/content" editorUrl="https://jnu-hci-lab.sleekeel31.chatgpt.site/admin"/>);
