import type {Item} from './content';
export const liPublications:Item[] = [
  {
    "id": "yang-li-publication-7",
    "title": {
      "zh": "配备外部人机界面的自动驾驶个人移动载具与行人交互的数据驱动因果发现：从心理状态到步行行为",
      "en": "Data-Driven Causal Discovery for Pedestrians-Autonomous Personal Mobility Vehicle Interactions With eHMIs: From Psychological States to Walking Behaviors"
    },
    "description": {
      "zh": "期刊论文 · 27(2) · 1921–1936 · Online 2025; issue 2026",
      "en": "Journal article · 27(2) · 1921–1936 · Online 2025; issue 2026"
    },
    "category": {
      "zh": "IEEE Transactions on Intelligent Transportation Systems",
      "en": "IEEE Transactions on Intelligent Transportation Systems"
    },
    "year": "2026",
    "authors": "Hailong Liu, Yang Li, Toshihiro Hiraoka, Takahiro Wada",
    "url": "https://doi.org/10.1109/TITS.2025.3632788",
    "image": ""
  },
  {
    "id": "yang-li-publication-1",
    "title": {
      "zh": "瓶颈道路场景中驾驶员对自动驾驶车辆的反应：横向偏移与外部人机界面的影响",
      "en": "Investigating driver responses to automated vehicles in a bottleneck scenario: The impact of lateral offset and eHMI"
    },
    "description": {
      "zh": "期刊论文 · 114 · 621–632",
      "en": "Journal article · 114 · 621–632"
    },
    "category": {
      "zh": "Transportation Research Part F: Traffic Psychology and Behaviour",
      "en": "Transportation Research Part F: Traffic Psychology and Behaviour"
    },
    "year": "2025",
    "authors": "Yang Li, Yee Mun Lee, Ruth Madigan, Armin Grunwald, Barbara Deml, Natasha Merat",
    "url": "https://doi.org/10.1016/j.trf.2025.06.016",
    "image": ""
  },
  {
    "id": "yang-li-publication-8",
    "title": {
      "zh": "无声的外部人机界面足够吗？以乘客为中心的自动驾驶个人移动载具外部人机界面实地研究",
      "en": "Is Silent External Human–Machine Interface (eHMI) Enough? A Passenger-Centric Study on Effective eHMI for Autonomous Personal Mobility Vehicles in the Field"
    },
    "description": {
      "zh": "期刊论文 · 41(2) · 891–905 · Online 2024; issue 2025",
      "en": "Journal article · 41(2) · 891–905 · Online 2024; issue 2025"
    },
    "category": {
      "zh": "International Journal of Human–Computer Interaction",
      "en": "International Journal of Human–Computer Interaction"
    },
    "year": "2025",
    "authors": "Hailong Liu, Yang Li, Zhe Zeng, Hao Cheng, Chen Peng, Takahiro Wada",
    "url": "https://doi.org/10.1080/10447318.2024.2306426",
    "image": ""
  },
  {
    "id": "yang-li-publication-10",
    "title": {
      "zh": "启发自动驾驶个人移动载具的外部人机界面设计：乘客人格特质对用户体验影响的因果发现",
      "en": "Inspiring External Human-Machine Interface Designs for Autonomous Personal Mobility Vehicle: Causal Discovering the Influence of Passengers’ Personality Traits on User Experience"
    },
    "description": {
      "zh": "会议论文 · 2675–2681",
      "en": "Conference paper · 2675–2681"
    },
    "category": {
      "zh": "IEEE/RSJ IROS 2025",
      "en": "IEEE/RSJ IROS 2025"
    },
    "year": "2025",
    "authors": "Hailong Liu, Zhe Zeng, Yang Li, Hao Cheng, Chen Peng, Takahiro Wada",
    "url": "https://doi.org/10.1109/IROS60139.2025.11246801",
    "image": ""
  },
  {
    "id": "yang-li-publication-9",
    "title": {
      "zh": "行人与配备外部人机界面的自动驾驶个人移动载具交互：从心理状态到步行行为的因果发现",
      "en": "Causal Discovery from Psychological States to Walking Behaviors for Pedestrians Interacting an APMV Equipped with eHMIs"
    },
    "description": {
      "zh": "会议论文 · 2976–2982",
      "en": "Conference paper · 2976–2982"
    },
    "category": {
      "zh": "IEEE IV 2024",
      "en": "IEEE IV 2024"
    },
    "year": "2024",
    "authors": "Hailong Liu, Yang Li, Toshihiro Hiraoka, Takahiro Wada",
    "url": "https://doi.org/10.1109/IV55156.2024.10588827",
    "image": ""
  },
  {
    "id": "yang-li-publication-2",
    "title": {
      "zh": "基于同步提示信息的多车瓶颈道路自动驾驶车辆与人工驾驶车辆协商方法",
      "en": "An AV-MV negotiation method based on synchronous prompt information on a multi-vehicle bottleneck road"
    },
    "description": {
      "zh": "期刊论文 · 20 · 100845",
      "en": "Journal article · 20 · 100845"
    },
    "category": {
      "zh": "Transportation Research Interdisciplinary Perspectives",
      "en": "Transportation Research Interdisciplinary Perspectives"
    },
    "year": "2023",
    "authors": "Yang Li, Hao Cheng, Zhe Zeng, Barbara Deml, Hailong Liu",
    "url": "https://doi.org/10.1016/j.trip.2023.100845",
    "image": ""
  },
  {
    "id": "yang-li-publication-3",
    "title": {
      "zh": "驾驶员是否对自动驾驶车辆的驾驶行为存在先入之见？基于瓶颈道路驾驶模拟实验的研究",
      "en": "Do Drivers have Preconceived Ideas about an Automated Vehicle's Driving Behaviour?"
    },
    "description": {
      "zh": "会议论文 · 291–299",
      "en": "Conference paper · 291–299"
    },
    "category": {
      "zh": "AutomotiveUI ’23",
      "en": "AutomotiveUI ’23"
    },
    "year": "2023",
    "authors": "Yang Li, Yee Mun Lee, Yue Yang, Kai Tian, Michael Daly, Anthony Horrobin, Albert Solernou, Natasha Merat",
    "url": "https://doi.org/10.1145/3580585.3607155",
    "image": ""
  },
  {
    "id": "yang-li-publication-11",
    "title": {
      "zh": "GaVe：采用单点校准、基于网络摄像头的注视交互售货界面",
      "en": "GaVe: A webcam-based gaze vending interface using one-point calibration"
    },
    "description": {
      "zh": "期刊论文 · 16(1)",
      "en": "Journal article · 16(1)"
    },
    "category": {
      "zh": "Journal of Eye Movement Research",
      "en": "Journal of Eye Movement Research"
    },
    "year": "2023",
    "authors": "Zhe Zeng, Sai Liu, Hao Cheng, Hailong Liu, Yang Li, Yu Feng, Felix Siebert",
    "url": "https://doi.org/10.16910/jemr.16.1.2",
    "image": ""
  },
  {
    "id": "yang-li-publication-5",
    "title": {
      "zh": "模糊交通场景中人工驾驶车辆驾驶员与自动驾驶车辆协商的基于人机界面的沟通方法",
      "en": "HMI-based Communication Methods for Negotiation between a Manually Driven Vehicle Driver and an Autonomous Vehicle in an Ambiguous Traffic Scenario"
    },
    "description": {
      "zh": "会议论文 · 244–249",
      "en": "Conference paper · 244–249"
    },
    "category": {
      "zh": "IEEE/SICE SII 2022",
      "en": "IEEE/SICE SII 2022"
    },
    "year": "2022",
    "authors": "Yang Li, Hailong Liu, Barbara Deml",
    "url": "https://doi.org/10.1109/SII52469.2022.9708797",
    "image": ""
  },
  {
    "id": "yang-li-publication-12",
    "title": {
      "zh": "基于时空信息的人机界面设计对驾驶员工作负荷的影响：以切入场景中的自适应巡航控制为例",
      "en": "The Influence of Spatio-temporal Based Human-Machine Interface Design on Driver Workload - A Case Study of Adaptive Cruise Control Using in Cutting-in Scenarios"
    },
    "description": {
      "zh": "会议论文 · 155–160",
      "en": "Conference paper · 155–160"
    },
    "category": {
      "zh": "IEEE/SICE SII 2022",
      "en": "IEEE/SICE SII 2022"
    },
    "year": "2022",
    "authors": "Wenjuan Wang, Fang You, Yang Li, Sebastian Feuerstack, Jianmin Wang",
    "url": "https://doi.org/10.1109/SII52469.2022.9708771",
    "image": ""
  },
  {
    "id": "yang-li-publication-4",
    "title": {
      "zh": "自动驾驶车辆驶入共享空间：面向弱势道路使用者的外部人机界面设计概念",
      "en": "Autonomous Vehicles Drive into Shared Spaces: eHMI Design Concept Focusing on Vulnerable Road Users"
    },
    "description": {
      "zh": "会议论文 · 1729–1736",
      "en": "Conference paper · 1729–1736"
    },
    "category": {
      "zh": "IEEE ITSC 2021",
      "en": "IEEE ITSC 2021"
    },
    "year": "2021",
    "authors": "Yang Li, Hao Cheng, Zhe Zeng, Hailong Liu, Monika Sester",
    "url": "https://doi.org/10.1109/ITSC48978.2021.9564515",
    "image": ""
  },
  {
    "id": "yang-li-publication-6",
    "title": {
      "zh": "人工驾驶车辆与自动驾驶车辆在瓶颈道路相遇：面向沟通问题的人机界面设计",
      "en": "Manually Driven Vehicle Encounters with Autonomous Vehicle in Bottleneck Roads: HMI Design for Communication Issues"
    },
    "description": {
      "zh": "会议论文 · 382–385",
      "en": "Conference paper · 382–385"
    },
    "category": {
      "zh": "HAI ’21",
      "en": "HAI ’21"
    },
    "year": "2021",
    "authors": "Yang Li, Hailong Liu, Barbara Deml",
    "url": "https://doi.org/10.1145/3472307.3484678",
    "image": ""
  },
  {
    "id": "yang-li-publication-13",
    "title": {
      "zh": "智能汽车的人机协同交互设计：以自适应巡航控制人机界面为例",
      "en": "Human-Computer Collaborative Interaction Design of Intelligent Vehicle—A Case Study of HMI of Adaptive Cruise Control"
    },
    "description": {
      "zh": "会议论文 · 296–314",
      "en": "Conference paper · 296–314"
    },
    "category": {
      "zh": "HCII 2021",
      "en": "HCII 2021"
    },
    "year": "2021",
    "authors": "Yujia Liu, Jun Zhang, Yang Li, Preben Hansen, Jianmin Wang",
    "url": "https://doi.org/10.1007/978-3-030-78358-7_21",
    "image": ""
  },
  {
    "id": "yang-li-publication-15",
    "title": {
      "zh": "城市双向道路车道受阻时的间隙接受行为及瓶颈通行辅助系统评估",
      "en": "Gap Acceptance at Blocked Lanes on Urban Two-Way Roads and Evaluation of a Bottleneck Assistant"
    },
    "description": {
      "zh": "会议论文",
      "en": "Conference paper"
    },
    "category": {
      "zh": "Transportation Research Board 100th Annual Meeting",
      "en": "Transportation Research Board 100th Annual Meeting"
    },
    "year": "2021",
    "authors": "Sofie Ehrhardt, Marvin V. Baumann, H. Sebastian Buck, Yang Li, Barbara Deml, Peter Vortisch",
    "url": "https://publikationen.bibliothek.kit.edu/1000131003",
    "image": ""
  },
  {
    "id": "yang-li-publication-16",
    "title": {
      "zh": "基于态势感知的汽车人机界面设计研究",
      "en": "Vehicle Human–Machine Interface Design Based on Situational Awareness"
    },
    "description": {
      "zh": "期刊论文 · 42(6), 29–36",
      "en": "Journal article · 42(6), 29–36"
    },
    "category": {
      "zh": "包装工程",
      "en": "Packaging Engineering"
    },
    "year": "2021",
    "authors": "Jianmin Wang, Yujia Liu, Yang Li, Fang You",
    "url": "https://doi.org/10.19554/j.cnki.1001-3563.2021.06.005",
    "image": ""
  },
  {
    "id": "yang-li-publication-14",
    "title": {
      "zh": "利用眼动追踪辅助设计用于变道的抬头显示安全指示器",
      "en": "Using Eye-Tracking to Help Design HUD-Based Safety Indicators for Lane Changes"
    },
    "description": {
      "zh": "会议论文 · 217–221",
      "en": "Conference paper · 217–221"
    },
    "category": {
      "zh": "AutomotiveUI ’17 Adjunct",
      "en": "AutomotiveUI ’17 Adjunct"
    },
    "year": "2017",
    "authors": "Fang You, Yang Li, Ronald Schroeter, Jürgen Friedrich, Jianmin Wang",
    "url": "https://doi.org/10.1145/3131726.3131757",
    "image": ""
  }
];
